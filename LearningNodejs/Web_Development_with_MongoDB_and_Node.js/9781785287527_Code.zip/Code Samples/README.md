DIRECTIONS
========================
* For those code sections where there is a package.json file at root folder, please run the "npm install" command as the same would pull in the dependencies before running the "node server.js" to invoke the express instance.
