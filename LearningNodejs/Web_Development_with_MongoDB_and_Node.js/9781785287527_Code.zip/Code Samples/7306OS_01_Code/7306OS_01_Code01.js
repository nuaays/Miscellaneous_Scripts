console.log('One');
console.log('Two');
setTimeout(function() {
    console.log('Three');
}, 2000);
console.log('Four');
console.log('Five');