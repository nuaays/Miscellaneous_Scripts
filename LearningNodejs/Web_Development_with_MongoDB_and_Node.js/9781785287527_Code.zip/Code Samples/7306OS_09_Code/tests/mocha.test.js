describe('Mocha', function() {
    'use strict';

    beforeEach(function() {});

    describe('First Test', function() {
        it('should assert 1 equals 1', function() {
            expect(1).to.eql(1);
        });
    });
});
