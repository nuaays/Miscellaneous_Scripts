module.exports = {
    index: function(req, res) {
        res.send('The home:index controller');
    }
};
